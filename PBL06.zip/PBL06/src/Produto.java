public interface Produto {
    public String getNome();
    public String getMarca();
    public Double getPreco();
    public void setPreco(double preco);
}

